# 实现与数据约定

## 在原项目中定位

下表路径相对目标仓库根目录，不依赖原来的 Windows 盘符。

| 职责 | 现有入口 |
| --- | --- |
| 首页和样式 | `front/src/pages/Dashboard.tsx`、`front/src/styles/dashboard.css` |
| 全局主题和工作区壳 | `front/src/index.css`、`front/src/styles/workspace.css` |
| 布局、首页标记和页宠显示 | `front/src/layouts/MainLayout.tsx` |
| 导航 | `front/src/components/layout/Sidebar.tsx` |
| 搜索命令面板 | `front/src/components/common/CommandPalette.tsx` |
| Markdown 纯文本摘要 | `front/src/components/note/notePresentation.ts` |
| API 与数据类型 | `front/src/api/{notes,knowledge,review}.ts`、`front/src/types/api.ts` |
| 用户、页宠和目标状态 | `front/src/stores/{useUserStore,usePetStore,useHabitStore}.ts` |
| 页宠角色与同步 | `front/src/components/pet/characters/registry.ts`、`front/src/hooks/useSettingsSync.ts` |
| 轻量图谱接口 | `backend/app/router/note_router.py` 的 `/note/graph` |
| 首页 UI 回归 | `front/scripts/verify-dashboard.cjs` |

本项目使用 React、TypeScript、React Router、Zustand、i18next、Lucide 和 CSS 变量。遵循现有依赖，不为了还原设计引入另一套 UI 框架。在 Vue 或其他项目中迁移视觉和组件契约，不要求移植 React 状态管理。

## 参考代码的边界

`assets/reference-code/Dashboard.tsx` 与 `dashboard.css` 是成对的实现快照。它们依赖上表中的 API、store、路由、图标、摘要函数和角色渲染器；不要原样复制后宣称是可直接运行的组件。

- 原项目：读取现行源码，做小范围修改；快照用于理解原设计。
- 其他项目：先映射 API/store/routes，再移植 JSX 层次与 CSS。静态原型可以用明确标识的样例 props，不构造假认证去请求真实服务。
- CSS 使用宿主 `.app-shell`、`.app-sidebar`、`.app-workspace` 和 `.is-dashboard`，基础 flex 布局来自现有工作区样式。新项目需适配宿主选择器，不能仅复制首页 CSS。
- 可选 `assets/theme.css` 只提供作用在 `.cloud-notebook-theme` 内的变量，不含 reset、导航样式或完整组件。放在布局最外层；先协调目标项目已有 token，避免意外重置其它页面。

## 数据到组件的映射

| 组件 | 原项目数据来源 | 注意事项 |
| --- | --- | --- |
| 最近笔记 | `notesApi.list({page:1,page_size:20,sort_by:'updated_at'})` 的 `.data` | `notes` 与 `total_count`；总量不是首页截断后的行数 |
| 最近资料 | `knowledgeApi.list()` 的 `.data` | `documents` 与 `total_count`；资源日期可能为空 |
| 图谱预览 | `notesApi.graph({include_semantic:false})` 的 `.data` | `nodes`、`links`；只展示真实边 |
| 待回顾 | `reviewApi.today()` 的返回值 | 该封装已经解包到业务数据，不能再读一次 `.data` |
| 用户名 | `useUserStore.userInfo` | 缺失时显示中性问候 |
| 页宠 | `usePetStore` 与 `getCharacter` | 使用用户角色、名称、好感度，不改写用户配置 |
| 今日目标 | `useHabitStore.taskDate/tasksDone` | 仅今日的完成记录有效 |
| 连续记录 | `useHabitStore.noteStreak` | 上次为今日或昨日才继续显示连续数 |

请求可并行；现有实现用 `Promise.allSettled` 保留成功结果。收到有效数据才渲染对应区块，对取消和卸载后的回调做保护。不要把整个首页绑定到最慢或最不稳定的模型调用。

### 可空字段

后端新建笔记的标签可能尚未生成，`tags:null` 是正常状态，不是用户数据损坏。

```tsx
type NoteSummary = {
  id: string
  title: string
  tags?: string[] | null
  updated_at?: string | null
}

const tags = note.tags ?? []
const detail = tags.slice(0, 2).join(' · ')
```

如果上游还可能返回非数组，先在 API 适配层验证 `Array.isArray`；不能用类型断言掩盖实际值。日期为空或无法解析时隐藏日期或显示占位，不格式化成 1970 年；可选对象/数组按实际接口契约处理，失败和空数据分开呈现。

### 图谱

首页默认不触发嵌入、语义检索或知识库遍历。原接口支持 `include_semantic=false`，完整图谱页通过用户点击再请求 `true`。

预览最多取六个节点，只保留两端都在预览里的边。中央书本是图谱入口，不是伪造知识节点；没有真实关系时不要为了好看给它连上所有节点。

语义结果状态 `not_requested/complete/partial/unavailable` 区分未请求、完成和失败。失败时保留已有图谱。复用 UI 不授权修改模型、代理、凭据、向量库或后台检索策略；目标接口不同，应单独适配或说明缺失能力。

### 成长状态

原项目好感度门槛：0–49 为 Lv.1、50–149 为 Lv.2、150 以上为 Lv.3。进度用当前阶段计算并限制 0–100，最高阶段显示已成长完成。优先调用现有函数，不将截图等级写死。

目标事件为 `note/review/chat`。条目点击用于进入业务页面，真正完成由保存笔记、回顾完成或对话完成事件决定。改 UI 不应触发这些奖励事件。

`Pet` 组件承载事件监听。首页通过 `.home-pet-hidden` 隐藏悬浮形象但保持挂载，避免成长与任务监听失效。其他架构可将视觉和事件处理拆开；不能为了样式删除必要逻辑。

## 导航与交互

| 动作 | 原项目目标 |
| --- | --- |
| 首页、品牌标志 | `/` |
| 新建、笔记列表、笔记详情 | `/notes/new`、`/notes`、`/notes/:id` |
| 上传与资料列表 | `/knowledge` |
| 问问知识库/问问 AI | `/chat` |
| 图谱 | `/graph` |
| 页宠、回顾、连续记录 | `/pet`、`/review`、`/habit` |
| 通知、资料、设置 | `/notifications`、`/profile`、`/settings` |

顶部搜索在原项目发送 `open-command-palette` 事件打开现有搜索，并保留键盘快捷键与 Escape。搜索入口不要做成只能装饰的假输入框；显示的快捷键应与实际平台行为一致。

整行记录使用一个主链接，附加菜单需要放在独立交互区域，不嵌套按钮和链接。导航收起后为图标提供 accessible name 和可访问的分组入口。

## 迁移顺序

优先建立主题与布局壳，再实现横幅/真实记录/快捷入口，随后接入图谱和成长区，最后验证响应式与异常状态。用户只要求某个区块时，不需要执行全套迁移。

新项目缺少页宠、任务或图谱服务时，明确说明功能边界，可保留中性的引导区或省略该模块。不要为 UI 复刻擅自增加后端服务、外部账号连接或用户数据写入。
